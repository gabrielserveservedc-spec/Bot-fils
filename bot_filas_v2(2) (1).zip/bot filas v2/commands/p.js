const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

// Caminho para o arquivo de dados JÁ EXISTENTE
const usersPath = path.join(__dirname, '../DataBaseJson/usersinfo.json'); 
const emojis = require('../DataBaseJson/emojis.json');

/**
 * Função adaptada para ler os dados do ranking existente (usersinfo.json).
 */
function readUserRank(userId) {
    let db = {};
    if (fs.existsSync(usersPath)) {
        try {
            db = JSON.parse(fs.readFileSync(usersPath, 'utf8'));
        } catch (e) {
            console.error('Erro ao ler usersinfo.json:', e);
            return null;
        }
    }
    // Retorna os dados no formato que seu MatchHandler já usa
    return db[userId] || { vitorias: 0, derrotas: 0, pontos: 0, partidas: 0 };
}


module.exports = {
    data: new SlashCommandBuilder()
        .setName('p')
        .setDescription('Mostra seu rank (vitórias/derrotas/pontos) ou o de outro usuário.')
        .addUserOption(option => 
            option.setName('usuario')
                .setDescription('Opcional: Selecione um usuário para ver o rank dele.')
                .setRequired(false)
        ),
    
    async execute(interaction) {
        const targetUser = interaction.options.getUser('usuario') || interaction.user;
        const stats = readUserRank(targetUser.id);
        
        const { vitorias: wins, derrotas: losses, pontos, partidas: totalMatches } = stats;
        
        // Proteção contra divisão por zero
        const winRate = totalMatches > 0 ? ((wins / totalMatches) * 100).toFixed(1) : 0;

        const embed = new EmbedBuilder()
            .setColor(0x0099ff)
            .setTitle(`${emojis.information_emoji || '🏆'} Ranking de ${targetUser.username}`)
            .setDescription(`Estatísticas de ${targetUser}`)
            .setThumbnail(targetUser.displayAvatarURL())
            .addFields(
                { name: 'Vitórias (W):', value: `${wins}`, inline: true },
                { name: 'Derrotas (L):', value: `${losses}`, inline: true },
                { name: 'Pontos Totais:', value: `${pontos}`, inline: true },
                { name: 'Total de Partidas:', value: `${totalMatches}`, inline: true },
                { name: 'Taxa de Vitória (W/L):', value: `${winRate}%`, inline: false }
            )
            .setFooter({ text: `Consultado por ${interaction.user.username}` });
            
        await interaction.reply({ embeds: [embed] });
    },
};