const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

// --- Caminhos Necessários ---
const usersPath = path.join(__dirname, '../DataBaseJson/usersinfo.json'); // << AQUI
const configPath = path.join(__dirname, '../config.json'); 
const permsPath = path.join(__dirname, '../DataBaseJson/perms.json'); 

// Função de permissão para garantir que é o owner/permitido (Função já existente no seu código)
function isOwnerOrPermitted(userId) {
    try {
        const config = JSON.parse(fs.readFileSync(configPath));
        if (config.ownerId === userId) return true;
        
        if (fs.existsSync(permsPath)) {
            const perms = JSON.parse(fs.readFileSync(permsPath));
            return Object.keys(perms).includes(userId);
        }
        return false;
    } catch {
        return false;
    }
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('resetrank')
        .setDescription('Reseta todos os dados de vitórias/derrotas/pontos do servidor. (Apenas Owner)'),
    
    async execute(interaction) {
        if (!isOwnerOrPermitted(interaction.user.id)) {
            return interaction.reply({ 
                content: '❌ Apenas o dono do bot pode usar este comando!', 
                ephemeral: true 
            });
        }

        try {
            // Reseta o arquivo usersinfo.json para um objeto vazio
            fs.writeFileSync(usersPath, JSON.stringify({}, null, 2));
            
            await interaction.reply({ 
                content: '✅ **Ranking resetado com sucesso!** Todos os dados de vitórias, derrotas e pontos (no usersinfo.json) foram zerados.', 
                ephemeral: true 
            });
        } catch (e) {
            console.error('Erro ao resetar usersinfo.json:', e);
            await interaction.reply({
                content: '❌ Erro ao tentar resetar o ranking. Verifique as permissões do arquivo.',
                ephemeral: true
            });
        }
    },
};